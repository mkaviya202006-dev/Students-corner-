import os, sys, tempfile, sqlite3, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from werkzeug.security import generate_password_hash
from app import create_app
from database.seed import seed

ADDR = dict(name="Asha", email="asha@example.com", phone="9876543210", address="12 Main Street",
            city="Chennai", state="Tamil Nadu", pin="600001", payment="cod")


class ShopTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True, "DATABASE": os.path.join(self.dir.name, "t.db"),
                               "UPLOAD_FOLDER": self.dir.name, "SECRET_KEY": "test"})
        self.app.init_db()
        c = sqlite3.connect(self.app.config["DATABASE"]); seed(c)
        c.execute("INSERT INTO users(name,email,password_hash,is_admin) VALUES ('Admin','admin@example.com',?,1)",
                  (generate_password_hash("adminpass1"),))
        c.commit(); c.close()
        self.c = self.app.test_client()

    def tearDown(self):
        self.dir.cleanup()

    def post(self, url, data=None, **kw):
        self.c.get("/")
        with self.c.session_transaction() as s:
            token = s["csrf"]
        return self.c.post(url, data={**(data or {}), "csrf_token": token}, **kw)

    def stock(self, pid):
        c = sqlite3.connect(self.app.config["DATABASE"])
        v = c.execute("SELECT stock FROM products WHERE id=?", (pid,)).fetchone()[0]; c.close(); return v

    def register_login(self, email="asha@example.com"):
        self.post("/register", dict(name="Asha", email=email, password="password1", confirm="password1"))
        return self.post("/login", dict(email=email, password="password1"))

    def test_homepage(self):
        r = self.c.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Everything You Need for Learning and Creativity", r.data)

    def test_product_listing_and_filters(self):
        r = self.c.get("/products")
        self.assertEqual(r.status_code, 200); self.assertIn("₹".encode(), r.data)
        self.assertIn(b"Geometry Box", self.c.get("/products?category=8").data)
        a = self.c.get("/products?sort=price_asc").data.decode()
        self.assertLess(a.index("Long Notebook"), a.index("Scientific Calculator"))

    def test_search(self):
        r = self.c.get("/products?q=calculator")
        self.assertIn(b"Scientific Calculator", r.data); self.assertNotIn(b"Water Colour", r.data)
        self.assertIn(b"No products match", self.c.get("/products?q=zzzz").data)

    def test_product_detail(self):
        self.assertEqual(self.c.get("/product/1").status_code, 200)
        self.assertEqual(self.c.get("/product/9999").status_code, 404)

    def test_registration_and_login(self):
        r = self.post("/register", dict(name="A", email="bad", password="password1", confirm="password1"))
        self.assertEqual(r.status_code, 400)
        r = self.register_login()
        self.assertEqual(r.status_code, 302)
        self.assertIn(b"Order history", self.c.get("/account").data)
        self.post("/logout"); self.assertEqual(self.c.get("/account").status_code, 302)
        self.assertEqual(self.post("/login", dict(email="asha@example.com", password="wrong")).status_code, 401)
        r = self.post("/register", dict(name="A", email="asha@example.com", password="password1", confirm="password1"))
        self.assertEqual(r.status_code, 400)

    def test_password_is_hashed(self):
        self.register_login()
        c = sqlite3.connect(self.app.config["DATABASE"])
        h = c.execute("SELECT password_hash FROM users WHERE email='asha@example.com'").fetchone()[0]; c.close()
        self.assertNotEqual(h, "password1")

    def test_csrf_required(self):
        self.assertEqual(self.c.post("/cart/add", data={"product_id": 1}).status_code, 400)

    def test_cart(self):
        self.post("/cart/add", dict(product_id=1, qty=2))
        self.assertIn(b"Smooth Ball Pen", self.c.get("/cart").data)
        self.post("/cart/update", dict(product_id=1, qty=3))
        with self.c.session_transaction() as s:
            self.assertEqual(s["cart"]["1"], 3)
        self.post("/cart/remove", dict(product_id=1))
        self.assertIn(b"Your cart is empty", self.c.get("/cart").data)

    def test_stock_validation(self):
        r = self.post("/cart/add", dict(product_id=24, qty=4), headers={"X-Requested-With": "fetch"})
        self.assertEqual(r.status_code, 400); self.assertFalse(r.get_json()["ok"])
        r = self.post("/cart/add", dict(product_id=24, qty=3), headers={"X-Requested-With": "fetch"})
        self.assertTrue(r.get_json()["ok"])
        self.post("/cart/update", dict(product_id=24, qty=9))
        with self.c.session_transaction() as s:
            self.assertEqual(s["cart"]["24"], 3)

    def test_checkout_validation(self):
        self.post("/cart/add", dict(product_id=1, qty=1))
        r = self.post("/checkout", {**ADDR, "phone": "123", "pin": "12"})
        self.assertEqual(r.status_code, 400); self.assertIn(b"10-digit", r.data)
        self.assertEqual(self.stock(1), 80)

    def test_successful_order(self):
        self.register_login()
        self.post("/cart/add", dict(product_id=1, qty=2))
        r = self.post("/checkout", ADDR)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.stock(1), 78)
        self.assertIn(b"placed", self.c.get(r.headers["Location"]).data)
        self.assertIn(b"Order #1", self.c.get("/account").data)
        self.assertIn(b"Your cart is empty", self.c.get("/cart").data)

    def test_failed_order_keeps_stock(self):
        self.post("/cart/add", dict(product_id=1, qty=2))
        self.post("/cart/add", dict(product_id=24, qty=3))
        c = sqlite3.connect(self.app.config["DATABASE"])
        c.execute("UPDATE products SET stock=1 WHERE id=24"); c.commit(); c.close()
        r = self.post("/checkout", ADDR)
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.stock(1), 80)  # rolled back
        c = sqlite3.connect(self.app.config["DATABASE"])
        self.assertEqual(c.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 0); c.close()

    def test_admin_authorization(self):
        self.assertEqual(self.c.get("/admin").status_code, 302)  # anonymous -> login
        self.register_login()
        for url in ("/admin", "/admin/products", "/admin/orders", "/admin/products/new"):
            self.assertEqual(self.c.get(url).status_code, 403)
        self.assertEqual(self.post("/admin/products/1/delete").status_code, 403)
        self.post("/logout")
        self.post("/login", dict(email="admin@example.com", password="adminpass1"))
        self.assertEqual(self.c.get("/admin").status_code, 200)
        r = self.post("/admin/products/new", dict(name="Test Pen", category_id=1, price="10", stock="5", description="x"))
        self.assertEqual(r.status_code, 302)
        self.assertIn(b"Test Pen", self.c.get("/admin/products").data)

    def test_admin_rejects_bad_upload(self):
        import io
        self.post("/login", dict(email="admin@example.com", password="adminpass1"))
        r = self.post("/admin/products/new", dict(name="X", category_id=1, price="10", stock="5",
                      image=(io.BytesIO(b"<script>alert(1)</script>"), "evil.png")),
                      content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_contact_form(self):
        self.assertEqual(self.post("/contact", dict(name="A", email="x", message="hi")).status_code, 400)
        self.assertEqual(self.post("/contact", dict(name="A", email="a@b.co", message="Hello there shop!")).status_code, 302)

    def test_invalid_pages(self):
        r = self.c.get("/no-such-page")
        self.assertEqual(r.status_code, 404); self.assertIn(b"Page not found", r.data)


if __name__ == "__main__":
    unittest.main()
