Product images uploaded by the admin are stored in static/uploads/. Products without an image get a generated SVG placeholder.
