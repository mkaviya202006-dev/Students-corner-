(function () {
  const toasts = document.getElementById("toasts");
  function toast(msg, type) {
    const t = document.createElement("div"); t.className = "toast " + (type || "success"); t.textContent = msg;
    toasts.appendChild(t); setTimeout(() => t.remove(), 3500);
  }
  document.querySelectorAll("#toasts .toast").forEach(t => setTimeout(() => t.remove(), 5000));
  const burger = document.querySelector(".burger"), menu = document.getElementById("menu");
  burger.addEventListener("click", () => burger.setAttribute("aria-expanded", menu.classList.toggle("open")));
  document.querySelectorAll("form[data-ajax]").forEach(f => f.addEventListener("submit", async e => {
    e.preventDefault();
    const btn = f.querySelector("button"); btn.disabled = true;
    try {
      const r = await fetch(f.action, { method: "POST", body: new FormData(f), headers: { "X-Requested-With": "fetch" } });
      const d = await r.json();
      toast(d.message, d.ok ? "success" : "error");
      if (d.ok) document.getElementById("cart-count").textContent = d.count;
    } catch (_) { toast("Network error. Please try again.", "error"); }
    btn.disabled = false;
  }));
})();
