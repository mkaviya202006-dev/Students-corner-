import os, re, uuid, sqlite3, secrets, getpass
from functools import wraps
import click
from flask import (Flask, g, render_template, request, redirect, url_for, session,
                   flash, jsonify, abort, Response)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from config import Config, BASE
from database.seed import seed as seed_db

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
STATUSES = ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]
MAGIC = {".png": b"\x89PNG", ".jpg": b"\xff\xd8", ".jpeg": b"\xff\xd8", ".gif": b"GIF8", ".webp": b"RIFF"}
COLORS = ["#ffe8a3", "#cfe3ff", "#ffd1dc", "#d4f1d0", "#e6d9ff", "#ffe0c2", "#c9f0f0", "#f6d6ff"]
EMOJI = ["🖊️", "📓", "🎨", "🎒", "📎", "📁", "🧮", "📐"]


def create_app(config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if config:
        app.config.update(config)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # ---------- database ----------
    def db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"], isolation_level=None)
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
        return g.db

    def q(sql, args=()):
        return db().execute(sql, args).fetchall()

    def one(sql, args=()):
        return db().execute(sql, args).fetchone()

    @app.teardown_appcontext
    def close_db(_):
        c = g.pop("db", None)
        if c:
            c.close()

    def init_db():
        c = sqlite3.connect(app.config["DATABASE"])
        with open(os.path.join(BASE, "database", "schema.sql")) as f:
            c.executescript(f.read())
        c.commit(); c.close()

    # ---------- helpers / security ----------
    @app.before_request
    def load_user():
        uid = session.get("user_id")
        g.user = one("SELECT * FROM users WHERE id=?", (uid,)) if uid else None
        if request.method == "POST":
            token = request.form.get("csrf_token") or request.headers.get("X-CSRFToken")
            if not token or token != session.get("csrf"):
                abort(400, "Invalid or missing security token. Please refresh and try again.")

    @app.after_request
    def headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "SAMEORIGIN"
        return resp

    def csrf_token():
        if "csrf" not in session:
            session["csrf"] = secrets.token_hex(16)
        return session["csrf"]

    def cart_items():
        cart = session.get("cart", {})
        items, total = [], 0
        for pid, qty in cart.items():
            p = one("SELECT * FROM products WHERE id=?", (int(pid),))
            if p:
                items.append({"p": p, "qty": qty, "line": p["price"] * qty})
                total += p["price"] * qty
        return items, total

    @app.context_processor
    def inject():
        return {"csrf_token": csrf_token, "user": g.get("user"),
                "cart_count": sum(session.get("cart", {}).values()),
                "all_categories": q("SELECT * FROM categories ORDER BY id")}

    @app.template_filter("inr")
    def inr(v):
        return "₹{:,.0f}".format(v) if float(v).is_integer() else "₹{:,.2f}".format(v)

    @app.template_filter("img")
    def img(p):
        return url_for("static", filename="uploads/" + p["image"]) if p["image"] else url_for("placeholder", pid=p["id"])

    def login_required(f):
        @wraps(f)
        def w(*a, **k):
            if not g.user:
                flash("Please log in to continue.", "error")
                return redirect(url_for("login", next=request.path))
            return f(*a, **k)
        return w

    def admin_required(f):
        @wraps(f)
        def w(*a, **k):
            if not g.user:
                return redirect(url_for("login", next=request.path))
            if not g.user["is_admin"]:
                abort(403)
            return f(*a, **k)
        return w

    def safe_next(url):
        return url if url and url.startswith("/") and not url.startswith("//") else None

    # ---------- public pages ----------
    @app.route("/")
    def index():
        return render_template(
            "index.html",
            featured=q("SELECT * FROM products WHERE featured=1 ORDER BY id LIMIT 4"),
            best=q("SELECT * FROM products ORDER BY sold DESC LIMIT 4"))

    @app.route("/placeholder/<int:pid>.svg")
    def placeholder(pid):
        p = one("SELECT c.id cid, p.name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?", (pid,))
        i = (p["cid"] - 1) % 8 if p else 0
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><rect width="400" height="300" fill="{COLORS[i]}"/>'
               f'<text x="200" y="175" font-size="110" text-anchor="middle">{EMOJI[i]}</text></svg>')
        return Response(svg, mimetype="image/svg+xml")

    @app.route("/products")
    def products():
        qs = request.args.get("q", "").strip()[:80]
        cat = request.args.get("category", type=int)
        sort = request.args.get("sort", "newest")
        order = {"price_asc": "price ASC", "price_desc": "price DESC", "name": "p.name ASC",
                 "popular": "sold DESC"}.get(sort, "p.id DESC")
        sql, args = "SELECT p.*, c.name cat FROM products p JOIN categories c ON c.id=p.category_id WHERE 1=1", []
        if qs:
            sql += " AND (p.name LIKE ? OR p.description LIKE ?)"; args += [f"%{qs}%"] * 2
        if cat:
            sql += " AND p.category_id=?"; args.append(cat)
        return render_template("products.html", items=q(sql + " ORDER BY " + order, args),
                               qs=qs, cat=cat, sort=sort)

    @app.route("/product/<int:pid>")
    def product_detail(pid):
        p = one("SELECT p.*, c.name cat FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?", (pid,))
        if not p:
            abort(404)
        rel = q("SELECT * FROM products WHERE category_id=? AND id!=? LIMIT 4", (p["category_id"], pid))
        return render_template("product_detail.html", p=p, related=rel)

    @app.route("/about")
    def about():
        return render_template("about.html")

    @app.route("/contact", methods=["GET", "POST"])
    def contact():
        if request.method == "POST":
            n, e, m = (request.form.get(k, "").strip() for k in ("name", "email", "message"))
            if not n or not EMAIL_RE.match(e) or len(m) < 10 or len(m) > 2000:
                flash("Enter your name, a valid email and a message of at least 10 characters.", "error")
                return render_template("contact.html", f=request.form), 400
            db().execute("INSERT INTO contact_messages(name,email,message) VALUES (?,?,?)", (n[:100], e[:150], m))
            flash("Thanks! Your message has been received.", "success")
            return redirect(url_for("contact"))
        return render_template("contact.html", f={})

    @app.route("/subscribe", methods=["POST"])
    def subscribe():
        e = request.form.get("email", "").strip().lower()
        if not EMAIL_RE.match(e):
            flash("Enter a valid email address to subscribe.", "error")
        else:
            db().execute("INSERT OR IGNORE INTO subscribers(email) VALUES (?)", (e,))
            flash("You're subscribed to our newsletter.", "success")
        return redirect(request.referrer or url_for("index"))

    # ---------- auth ----------
    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            n, e = request.form.get("name", "").strip(), request.form.get("email", "").strip().lower()
            pw, pw2 = request.form.get("password", ""), request.form.get("confirm", "")
            err = None
            if not n or len(n) > 100: err = "Enter your name."
            elif not EMAIL_RE.match(e): err = "Enter a valid email address."
            elif len(pw) < 8: err = "Password must be at least 8 characters."
            elif pw != pw2: err = "Passwords do not match."
            elif one("SELECT 1 FROM users WHERE email=?", (e,)): err = "An account with this email already exists."
            if err:
                flash(err, "error")
                return render_template("register.html", f=request.form), 400
            db().execute("INSERT INTO users(name,email,password_hash) VALUES (?,?,?)",
                         (n, e, generate_password_hash(pw)))
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        return render_template("register.html", f={})

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            e, pw = request.form.get("email", "").strip().lower(), request.form.get("password", "")
            u = one("SELECT * FROM users WHERE email=?", (e,))
            if not u or not check_password_hash(u["password_hash"], pw):
                flash("Incorrect email or password.", "error")
                return render_template("login.html", f=request.form), 401
            cart, csrf = session.get("cart"), None
            session.clear()
            session["user_id"] = u["id"]
            if cart: session["cart"] = cart
            flash(f"Welcome back, {u['name']}!", "success")
            return redirect(safe_next(request.args.get("next")) or url_for("index"))
        return render_template("login.html", f={})

    @app.route("/logout", methods=["POST"])
    def logout():
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("index"))

    @app.route("/account")
    @login_required
    def account():
        orders = q("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (g.user["id"],))
        items = {o["id"]: q("SELECT * FROM order_items WHERE order_id=?", (o["id"],)) for o in orders}
        return render_template("account.html", orders=orders, items=items)

    # ---------- cart ----------
    @app.route("/cart")
    def cart():
        items, total = cart_items()
        return render_template("cart.html", items=items, total=total)

    def cart_reply(msg, ok=True, code=200):
        if request.headers.get("X-Requested-With") == "fetch":
            return jsonify(ok=ok, message=msg, count=sum(session.get("cart", {}).values())), code
        flash(msg, "success" if ok else "error")
        return redirect(request.referrer or url_for("cart"))

    @app.route("/cart/add", methods=["POST"])
    def cart_add():
        pid, qty = request.form.get("product_id", type=int), request.form.get("qty", 1, type=int)
        p = one("SELECT * FROM products WHERE id=?", (pid,)) if pid else None
        if not p: return cart_reply("Product not found.", False, 404)
        if qty < 1: return cart_reply("Quantity must be at least 1.", False, 400)
        c = session.get("cart", {})
        new = c.get(str(pid), 0) + qty
        if new > p["stock"]:
            return cart_reply(f"Only {p['stock']} of {p['name']} in stock.", False, 400)
        c[str(pid)] = new; session["cart"] = c
        return cart_reply(f"{p['name']} added to cart.")

    @app.route("/cart/update", methods=["POST"])
    def cart_update():
        pid, qty = request.form.get("product_id", type=int), request.form.get("qty", type=int)
        c = session.get("cart", {})
        p = one("SELECT * FROM products WHERE id=?", (pid,)) if pid else None
        if not p or str(pid) not in c or qty is None:
            return cart_reply("Item not in cart.", False, 400)
        if qty <= 0:
            c.pop(str(pid)); msg, ok = "Item removed.", True
        elif qty > p["stock"]:
            msg, ok = f"Only {p['stock']} of {p['name']} in stock.", False
        else:
            c[str(pid)] = qty; msg, ok = "Cart updated.", True
        session["cart"] = c
        return cart_reply(msg, ok, 200 if ok else 400)

    @app.route("/cart/remove", methods=["POST"])
    def cart_remove():
        c = session.get("cart", {}); c.pop(request.form.get("product_id", ""), None)
        session["cart"] = c
        return cart_reply("Item removed.")

    # ---------- checkout / orders ----------
    def place_order(form, items, total):
        conn = db()
        conn.execute("BEGIN IMMEDIATE")
        try:
            for it in items:
                cur = conn.execute("UPDATE products SET stock=stock-?, sold=sold+? WHERE id=? AND stock>=?",
                                   (it["qty"], it["qty"], it["p"]["id"], it["qty"]))
                if cur.rowcount == 0:
                    raise ValueError(f"Sorry, {it['p']['name']} no longer has enough stock.")
            cur = conn.execute(
                "INSERT INTO orders(user_id,name,email,phone,address,city,state,pin,payment_method,total)"
                " VALUES (?,?,?,?,?,?,?,?,?,?)",
                (g.user["id"] if g.user else None, form["name"], form["email"], form["phone"], form["address"],
                 form["city"], form["state"], form["pin"], form["payment"], total))
            oid = cur.lastrowid
            for it in items:
                conn.execute("INSERT INTO order_items(order_id,product_id,name,price,qty) VALUES (?,?,?,?,?)",
                             (oid, it["p"]["id"], it["p"]["name"], it["p"]["price"], it["qty"]))
            conn.execute("COMMIT")
            return oid
        except Exception:
            conn.execute("ROLLBACK")
            raise

    @app.route("/checkout", methods=["GET", "POST"])
    def checkout():
        items, total = cart_items()
        if not items:
            flash("Your cart is empty.", "error")
            return redirect(url_for("cart"))
        f = request.form if request.method == "POST" else {
            "name": g.user["name"] if g.user else "", "email": g.user["email"] if g.user else ""}
        if request.method == "POST":
            d = {k: request.form.get(k, "").strip() for k in
                 ("name", "email", "phone", "address", "city", "state", "pin", "payment")}
            errs = []
            if not d["name"]: errs.append("Name is required.")
            if not EMAIL_RE.match(d["email"]): errs.append("Enter a valid email address.")
            if not re.fullmatch(r"[6-9]\d{9}", d["phone"]): errs.append("Enter a valid 10-digit Indian mobile number.")
            if len(d["address"]) < 5: errs.append("Delivery address is required.")
            if not d["city"]: errs.append("City is required.")
            if not d["state"]: errs.append("State is required.")
            if not re.fullmatch(r"[1-9]\d{5}", d["pin"]): errs.append("Enter a valid 6-digit PIN code.")
            if d["payment"] not in ("cod", "simulated"): errs.append("Choose a payment method.")
            if not errs:
                try:
                    oid = place_order(d, items, total)
                    session["cart"] = {}
                    session["my_orders"] = session.get("my_orders", []) + [oid]
                    return redirect(url_for("order_confirmation", oid=oid))
                except ValueError as ex:
                    errs.append(str(ex))
            for e in errs: flash(e, "error")
            return render_template("checkout.html", items=items, total=total, f=request.form), 400
        return render_template("checkout.html", items=items, total=total, f=f)

    @app.route("/order/<int:oid>")
    def order_confirmation(oid):
        o = one("SELECT * FROM orders WHERE id=?", (oid,))
        if not o or not ((g.user and o["user_id"] == g.user["id"]) or oid in session.get("my_orders", [])):
            abort(404)
        return render_template("order.html", o=o, items=q("SELECT * FROM order_items WHERE order_id=?", (oid,)))

    # ---------- admin ----------
    @app.route("/admin")
    @admin_required
    def admin_dashboard():
        s = {"products": one("SELECT COUNT(*) FROM products")[0], "orders": one("SELECT COUNT(*) FROM orders")[0],
             "customers": one("SELECT COUNT(*) FROM users WHERE is_admin=0")[0],
             "revenue": one("SELECT COALESCE(SUM(total),0) FROM orders WHERE status!='Cancelled'")[0],
             "low": q("SELECT * FROM products WHERE stock<=5 ORDER BY stock")}
        return render_template("admin/dashboard.html", s=s,
                               recent=q("SELECT * FROM orders ORDER BY id DESC LIMIT 5"),
                               customers=q("SELECT name,email,created_at FROM users WHERE is_admin=0 ORDER BY id DESC LIMIT 10"))

    @app.route("/admin/products")
    @admin_required
    def admin_products():
        return render_template("admin/products.html", items=q(
            "SELECT p.*, c.name cat FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC"))

    def save_image(file):
        if not file or not file.filename:
            return None
        ext = os.path.splitext(secure_filename(file.filename))[1].lower()
        head = file.stream.read(12); file.stream.seek(0)
        if ext not in MAGIC or not head.startswith(MAGIC[ext]) or (ext == ".webp" and head[8:12] != b"WEBP"):
            raise ValueError("Image must be a valid PNG, JPG, GIF or WEBP file (max 2 MB).")
        name = uuid.uuid4().hex + ext
        file.save(os.path.join(app.config["UPLOAD_FOLDER"], name))
        return name

    def product_form(pid=None):
        p = one("SELECT * FROM products WHERE id=?", (pid,)) if pid else None
        if pid and not p: abort(404)
        if request.method == "POST":
            f = request.form
            try:
                name, desc = f.get("name", "").strip(), f.get("description", "").strip()
                price, stock, cat = float(f.get("price", "")), int(f.get("stock", "")), int(f.get("category_id", ""))
                if not name or price < 0 or stock < 0 or not one("SELECT 1 FROM categories WHERE id=?", (cat,)):
                    raise ValueError
            except ValueError:
                flash("Check the form: name, a non-negative price and stock, and a category are required.", "error")
                return render_template("admin/product_form.html", p=f, pid=pid), 400
            try:
                image = save_image(request.files.get("image")) or (p["image"] if p else None)
            except ValueError as ex:
                flash(str(ex), "error")
                return render_template("admin/product_form.html", p=f, pid=pid), 400
            vals = (name[:150], cat, price, desc[:500], stock, image, 1 if f.get("featured") else 0)
            if pid:
                db().execute("UPDATE products SET name=?,category_id=?,price=?,description=?,stock=?,image=?,featured=? WHERE id=?", vals + (pid,))
            else:
                db().execute("INSERT INTO products(name,category_id,price,description,stock,image,featured) VALUES (?,?,?,?,?,?,?)", vals)
            flash("Product saved.", "success")
            return redirect(url_for("admin_products"))
        return render_template("admin/product_form.html", p=p or {}, pid=pid)

    @app.route("/admin/products/new", methods=["GET", "POST"])
    @admin_required
    def admin_product_new():
        return product_form()

    @app.route("/admin/products/<int:pid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_product_edit(pid):
        return product_form(pid)

    @app.route("/admin/products/<int:pid>/delete", methods=["POST"])
    @admin_required
    def admin_product_delete(pid):
        db().execute("DELETE FROM products WHERE id=?", (pid,))
        flash("Product deleted.", "success")
        return redirect(url_for("admin_products"))

    @app.route("/admin/orders")
    @admin_required
    def admin_orders():
        orders = q("SELECT * FROM orders ORDER BY id DESC")
        items = {o["id"]: q("SELECT * FROM order_items WHERE order_id=?", (o["id"],)) for o in orders}
        return render_template("admin/orders.html", orders=orders, items=items, statuses=STATUSES)

    @app.route("/admin/orders/<int:oid>/status", methods=["POST"])
    @admin_required
    def admin_order_status(oid):
        st = request.form.get("status")
        if st not in STATUSES: abort(400)
        db().execute("UPDATE orders SET status=? WHERE id=?", (st, oid))
        flash(f"Order #{oid} marked {st}.", "success")
        return redirect(url_for("admin_orders"))

    # ---------- errors ----------
    @app.errorhandler(404)
    def e404(_): return render_template("404.html"), 404
    @app.errorhandler(403)
    def e403(_): return render_template("403.html"), 403
    @app.errorhandler(400)
    def e400(e):
        flash(getattr(e, "description", "Bad request."), "error")
        return render_template("400.html"), 400
    @app.errorhandler(413)
    def e413(_):
        flash("That file is too large (max 2 MB).", "error")
        return render_template("400.html"), 413
    @app.errorhandler(500)
    def e500(_): return render_template("500.html"), 500

    # ---------- CLI ----------
    @app.cli.command("init-db")
    def init_db_cmd():
        init_db(); click.echo("Database initialised.")

    @app.cli.command("seed")
    def seed_cmd():
        init_db()
        c = sqlite3.connect(app.config["DATABASE"]); seed_db(c); c.commit(); c.close()
        click.echo("Sample categories and products added.")

    @app.cli.command("create-admin")
    @click.option("--email", prompt=True)
    @click.option("--name", default="Administrator")
    @click.password_option()
    def create_admin(email, name, password):
        init_db()
        if len(password) < 8 or not EMAIL_RE.match(email):
            raise click.ClickException("Use a valid email and a password of 8+ characters.")
        c = sqlite3.connect(app.config["DATABASE"])
        c.execute("INSERT INTO users(name,email,password_hash,is_admin) VALUES (?,?,?,1) "
                  "ON CONFLICT(email) DO UPDATE SET password_hash=excluded.password_hash, is_admin=1",
                  (name, email.lower(), generate_password_hash(password)))
        c.commit(); c.close()
        click.echo("Admin account ready.")

    app.init_db = init_db
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
