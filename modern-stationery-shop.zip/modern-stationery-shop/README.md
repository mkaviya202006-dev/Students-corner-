# Modern Stationery Shop Website

A complete e-commerce demo for a stationery shop: browse, search, cart, checkout (Cash on Delivery or a clearly simulated payment), customer accounts and an admin dashboard. Built as a college project.

## Features
- Home page with hero, featured/best-selling products, categories, offers, reviews, newsletter
- Products page with search, category filter and sorting; 23 sample products in 8 categories (prices in ₹)
- Product details with quantity selector and related products
- Session cart with stock validation, quantity changes, toast notifications
- Checkout with server-side validation; orders are created in one database transaction (a failed order never reduces stock)
- Registration, login/logout, hashed passwords, account page with order history
- Admin dashboard: statistics, add/edit/delete products, safe image upload, stock, orders and statuses, customers
- About and Contact pages (messages saved to the database)
- Security: CSRF tokens, parameterized SQL, Jinja auto-escaping, admin authorization, upload validation, HttpOnly/SameSite cookies

## Technology stack
Python Flask, SQLite, HTML5/CSS3/JavaScript, Font Awesome (CDN). No paid services.

## Prerequisites
Python 3.9+ and an internet connection for Font Awesome icons (the site still works without it).

## Installation
**Windows PowerShell**
```powershell
cd modern-stationery-shop
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```
(If activation is blocked: `Set-ExecutionPolicy -Scope Process Bypass`.)

**macOS / Linux**
```bash
cd modern-stationery-shop
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
Edit `.env` and set `SECRET_KEY` to a long random string.

## Database and sample data
```
flask --app app init-db     # creates tables from database/schema.sql
flask --app app seed        # adds categories and sample products
```

## Create the administrator
```
flask --app app create-admin
```
You are prompted for an email and password (8+ characters). Nothing is hardcoded. Running it again for the same email resets that admin's password.

## Run
```
python app.py
```
Open http://127.0.0.1:5000. Admin dashboard: log in as the admin, then use **Admin** in the menu (http://127.0.0.1:5000/admin). Set `FLASK_DEBUG=1` for debug mode (development only).

## Tests
```
python -m unittest tests.test_app -v
```
(`pytest` also works if installed.) Tests use a temporary database.

## Troubleshooting
- **`no such table`**: run `flask --app app init-db` and `flask --app app seed`.
- **`flask` not found**: activate the virtual environment, or use `python -m flask --app app ...`.
- **Icons missing**: Font Awesome loads from a CDN; check your internet connection.
- **"Invalid or missing security token"**: refresh the page (the session cookie expired or was cleared).
- **Logged out after restart**: set a fixed `SECRET_KEY` in `.env`.
- **Port in use**: `flask --app app run --port 5001`.
- **Image upload rejected**: use PNG/JPG/GIF/WEBP under 2 MB.

## Notes
Demo only: "simulated payment" charges nothing and collects no card details. Shop address, phone and email are placeholders to replace in `templates/base.html` and `templates/contact.html`. For deployment, use a production server (e.g. gunicorn), HTTPS and `SESSION_COOKIE_SECURE=1`.
