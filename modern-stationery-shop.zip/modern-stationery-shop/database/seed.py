"""Sample data. Run: flask --app app seed"""
CATEGORIES = [
    ("Pens and Pencils", "fa-pen"), ("Notebooks and Diaries", "fa-book"),
    ("Art and Craft Supplies", "fa-palette"), ("School Supplies", "fa-school"),
    ("Office Supplies", "fa-paperclip"), ("Files and Folders", "fa-folder-open"),
    ("Calculators", "fa-calculator"), ("Geometry Boxes", "fa-ruler-combined"),
]
# (name, category index, price INR, stock, description, featured)
PRODUCTS = [
    ("Smooth Ball Pen Pack (10, Blue)", 0, 120, 80, "Quick-dry ink with a 0.7 mm tip for neat everyday writing.", 1),
    ("HB Graphite Pencils (Box of 10)", 0, 90, 120, "Pre-sharpened, smudge-free pencils for school and sketching.", 0),
    ("Fine Liner Pen 0.5 mm", 0, 150, 45, "Precision needle-point pen for notes and technical drawing.", 0),
    ("Colour Gel Pen Set (12 Shades)", 0, 180, 60, "Vibrant gel inks for journaling and highlighting.", 1),
    ("Spiral Notebook, 300 Pages", 1, 140, 70, "Ruled A4 notebook with a sturdy cover and perforated pages.", 1),
    ("Leather-Finish Daily Diary", 1, 320, 25, "A5 dated diary with a ribbon marker and elastic closure.", 0),
    ("Long Notebook, 172 Pages", 1, 75, 150, "Single-line long book, ideal for classroom notes.", 0),
    ("Dotted Bullet Journal A5", 1, 399, 18, "Thick cream pages that handle fountain pens and markers.", 1),
    ("Water Colour Set (24 Shades)", 2, 210, 40, "Smooth pans with a free brush for beginners.", 1),
    ("Oil Pastels (50 Shades)", 2, 260, 35, "Rich, blendable colours for art classes.", 0),
    ("Acrylic Paint Set (12 Tubes)", 2, 450, 15, "Artist-grade acrylics for canvas, wood and craft.", 0),
    ("A4 Sketch Pad (40 Sheets)", 2, 130, 55, "180 gsm drawing paper with a hard backing.", 0),
    ("Steel Water Bottle 750 ml", 3, 299, 30, "Leak-proof bottle that keeps drinks cool through the day.", 0),
    ("Two-Layer Pencil Box", 3, 160, 50, "Roomy compartments with a secure latch.", 0),
    ("Blunt-Tip Safety Scissors", 3, 60, 90, "Child-safe scissors with comfortable grips.", 0),
    ("Stapler with 1000 Pins", 4, 95, 65, "Compact stapler for up to 20 sheets.", 0),
    ("Sticky Notes Pack (5 Colours)", 4, 110, 100, "Repositionable notes for reminders and revision.", 1),
    ("Mesh Desk Organiser", 4, 350, 20, "Four compartments to keep your desk tidy.", 0),
    ("Zip Folder A4 (Pack of 5)", 5, 150, 60, "Waterproof zip pouches in assorted colours.", 0),
    ("Document File, 20 Pockets", 5, 180, 40, "Clear pockets protect certificates and notes.", 0),
    ("Scientific Calculator, 552 Functions", 6, 1350, 12, "Natural display with equation and table modes.", 1),
    ("Desktop Calculator, 12 Digits", 6, 540, 28, "Large display and solar plus battery power.", 0),
    ("Geometry Box with Compass", 7, 130, 85, "Compass, divider, protractor, set squares and ruler.", 0),
    ("Premium Metal Geometry Set", 7, 210, 3, "Metal-tipped instruments in a durable tin case.", 0),
]
def seed(db):
    for name, icon in CATEGORIES:
        db.execute("INSERT OR IGNORE INTO categories(name, icon) VALUES (?,?)", (name, icon))
    ids = [r[0] for r in db.execute("SELECT id FROM categories ORDER BY id")]
    if db.execute("SELECT COUNT(*) FROM products").fetchone()[0]:
        return
    for n, c, p, s, d, f in PRODUCTS:
        db.execute("INSERT INTO products(name,category_id,price,stock,description,featured,sold)"
                   " VALUES (?,?,?,?,?,?,?)", (n, ids[c], p, s, d, f, (p * 7) % 50))
